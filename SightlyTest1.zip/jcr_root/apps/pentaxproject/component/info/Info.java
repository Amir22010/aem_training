package apps.pentaxproject.component.info;
  
import com.adobe.cq.sightly.WCMUse;
  
public class Info extends WCMUse {
    private String lowerCaseTitle;
    private String lowerCaseDescription;
    private String upperCaseText;
  
    @Override
    public void activate() throws Exception {
        lowerCaseTitle = getProperties().get("title", "").toLowerCase();
        lowerCaseDescription = getProperties().get("description", "").toLowerCase();
        upperCaseText = getProperties().get("text","").toUpperCase();
    }
  
    public String getLowerCaseTitle() {
        return lowerCaseTitle;
    }
  
    public String getLowerCaseDescription() {
        return lowerCaseDescription;
    }

    public String getUpperCaseText() {
        return upperCaseText;
    }
}